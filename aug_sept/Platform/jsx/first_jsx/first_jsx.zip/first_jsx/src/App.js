import React from "react";
import logo from "./logo.svg";
import "./App.css";

function App() {
  return (
    <div className="App">
      <h1 className="my-class">This is JSX</h1>
      <h2>Things I need to do:</h2>
      <ol>
        <li>Learn React</li>
        <li>Go Skiing this winter</li>
        <li>Skate in the snakerun by next summer</li>
        <li>Deploy a project</li>
      </ol>
    </div>
  );
}
export default App;
