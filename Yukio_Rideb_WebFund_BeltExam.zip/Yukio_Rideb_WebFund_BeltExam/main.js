console.log("there is no spoon")
console.log("Shawn says to keep your Likes assignment handy for the Exam");
console.log("W2D2 20:37");
console.log("\'Even if it\'s not styled properly, we should [at least] have every word, every picture, every div\'");
console.log("W2D2 28:30");
