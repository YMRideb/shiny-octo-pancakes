function login(element){
    element.innerText = "Logout";
}

function like(){
    alert("You liked a dojonary word!")
}

function hide(element){
    element.remove();
}